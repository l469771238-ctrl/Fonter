package com.local.fontanalyzer

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SweepGradient
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.MotionEvent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import java.util.zip.ZipInputStream

class MainActivity : Activity() {
    private val pickerRequest = 101
    private val saveRequest = 102
    private var pendingSaveFile: File? = null
    private var pendingSaveName: String = "font.ttf"
    private var nextId = 1
    private lateinit var blocksHost: LinearLayout
    private val blocks = mutableListOf<PreviewBlock>()
    private val bg = Color.rgb(7, 10, 24)
    private val primaryText = Color.rgb(244, 247, 255)
    private val muted = Color.rgb(164, 177, 205)
    private val violet = Color.rgb(153, 111, 255)
    private val cyan = Color.rgb(77, 220, 255)

    private data class FontChoice(
        val name: String,
        val file: File,
        val family: String,
        val style: String,
        val extension: String
    ) {
        val displayName: String get() = "$family${if (style.isNotBlank() && !style.equals("Regular", true)) " — $style" else ""}"
        val identity: String get() = (family.trim().lowercase(Locale.ROOT) + "|" + style.trim().lowercase(Locale.ROOT))
    }
    private data class PreviewBlock(
        val id: Int,
        val card: LinearLayout,
        val fileLabel: TextView,
        val preview: TextView,
        val input: EditText,
        val sizeLabel: TextView,
        var fontFile: File? = null,
        var fontName: String = "",
        var sourceName: String = "font.ttf",
        var size: Int = 30,
        var textColor: Int = Color.rgb(244, 247, 255),
        var previewBackground: Int = Color.rgb(28, 29, 54),
        var saveButton: Button? = null,
        var textColorButton: Button? = null,
        var backgroundColorButton: Button? = null
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            window.isNavigationBarContrastEnforced = false
            window.isStatusBarContrastEnforced = false
        }
        buildScreen()
        addPreviewBlock()
        addPreviewBlock()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(16))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(7, 10, 24), Color.rgb(17, 17, 48), Color.rgb(8, 25, 43)))
        }
        val scroll = ScrollView(this).apply { clipToPadding = false; isFillViewport = true }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = glass(0x24FFFFFF, violet)
            setPadding(dp(18), dp(18), dp(18), dp(18))
            elevation = dp(5).toFloat()
        }
        top.addView(TextView(this).apply {
            text = "FONT LAB  ✦"
            textSize = 12f
            letterSpacing = .22f
            setTextColor(cyan)
            typeface = Typeface.DEFAULT_BOLD
        })
        top.addView(TextView(this).apply {
            text = "مساحة تجارب الخطوط"
            textSize = 27f
            setTextColor(primaryText)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setPadding(0, dp(7), 0, dp(3))
        })
        top.addView(TextView(this).apply {
            text = "ارفع خطوطك، اكتب مباشرة، وقارن النتائج جنبًا إلى جنب."
            textSize = 14f
            setTextColor(muted)
        })
        content.addView(top, marginParams(bottom = 14))

        val toolbar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val add = button("＋  إضافة بلوك") { addPreviewBlock() }
        toolbar.addView(add, LinearLayout.LayoutParams(0, dp(48), 1f))
        val clear = button("مسح الكل") {
            blocksHost.removeAllViews()
            blocks.clear()
            addPreviewBlock()
        }
        toolbar.addView(clear, LinearLayout.LayoutParams(dp(112), dp(48)).apply { marginStart = dp(8) })
        content.addView(toolbar, marginParams(bottom = 12))

        blocksHost = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(blocksHost)
        content.addView(TextView(this).apply {
            text = "يدعم المعاينة المباشرة لملفات TTF وOTF وTTC. ويمكن فتح ZIP لاستخراج الخطوط الموجودة بداخله. صيغ WOFF/WOFF2 قد تحتاج تحويلًا قبل عرضها في Android."
            textSize = 12f
            setTextColor(muted)
            setPadding(dp(4), dp(10), dp(4), dp(12))
        })
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun addPreviewBlock() {
        val id = nextId++
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = glass(0x1FFFFFFF, if (id % 2 == 0) cyan else violet)
            elevation = dp(3).toFloat()
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(this).apply {
            text = "LIVE PREVIEW  /  %02d".format(id)
            textSize = 11f
            letterSpacing = .12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(if (id % 2 == 0) cyan else violet)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(button("×") {
            if (blocks.size <= 1) {
                Toast.makeText(this, "لازم تسيب بلوك واحد على الأقل", Toast.LENGTH_SHORT).show()
            } else {
                blocksHost.removeView(card)
                blocks.removeAll { it.id == id }
            }
        }.apply { textSize = 20f }, LinearLayout.LayoutParams(dp(44), dp(40)))
        card.addView(head)

        val fileLabel = TextView(this).apply {
            text = "لم يتم اختيار خط لهذا البلوك"
            textSize = 12f
            setTextColor(muted)
            setPadding(0, dp(5), 0, dp(8))
        }
        card.addView(fileLabel)
        card.addView(button("↑  رفع ملف خط أو ZIP") { launchPicker(id) }, marginParams(bottom = 8))

        val input = EditText(this).apply {
            setSingleLine(false)
            minLines = 2
            maxLines = 4
            textSize = 15f
            setTextColor(primaryText)
            setHintTextColor(muted)
            hint = "اكتب نص المعاينة هنا…"
            setText("أبجد هوز — Qworld — 1234567890")
            background = glass(0x14FFFFFF, cyan)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        card.addView(input, marginParams(bottom = 10))

        val sizeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        sizeRow.addView(TextView(this).apply { text = "حجم المعاينة"; textSize = 12f; setTextColor(muted) },
            LinearLayout.LayoutParams(0, -2, 1f))
        val sizeLabel = TextView(this).apply { text = "30 px"; textSize = 12f; setTextColor(cyan); typeface = Typeface.DEFAULT_BOLD }
        sizeRow.addView(sizeLabel)
        card.addView(sizeRow)
        val seek = SeekBar(this).apply { max = 112; progress = 22 }
        card.addView(seek, marginParams(bottom = 8))

        val previewTools = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val textColorButton = button("A  لون النص") { showColorPalette(null, true) }
        val backgroundColorButton = button("▰  الخلفية") { showColorPalette(null, false) }
        previewTools.addView(textColorButton, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(6) })
        previewTools.addView(backgroundColorButton, LinearLayout.LayoutParams(0, dp(42), 1f))
        card.addView(previewTools, marginParams(bottom = 8))

        val preview = TextView(this).apply {
            text = input.text.toString()
            textSize = 30f
            gravity = Gravity.CENTER
            setTextColor(primaryText)
            setPadding(dp(12), dp(22), dp(12), dp(22))
            background = solidPreviewBackground(Color.rgb(28, 29, 54), violet)
            minHeight = dp(105)
        }
        card.addView(preview, marginParams(bottom = 8))
        val saveButton = button("💾  حفظ ملف الخط") { saveBlockFont(id) }
        card.addView(saveButton)
        val block = PreviewBlock(id, card, fileLabel, preview, input, sizeLabel,
            textColor = primaryText, previewBackground = Color.rgb(28, 29, 54),
            saveButton = saveButton, textColorButton = textColorButton, backgroundColorButton = backgroundColorButton)
        textColorButton.setOnClickListener { showColorPalette(block, true) }
        backgroundColorButton.setOnClickListener { showColorPalette(block, false) }
        blocks.add(block)
        input.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                preview.text = s?.toString().orEmpty().ifBlank { "اكتب نصًا للمعاينة" }
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                block.size = 8 + progress
                sizeLabel.text = "${block.size} px"
                preview.textSize = block.size.toFloat()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        blocksHost.addView(card, marginParams(bottom = 14))
    }

    private fun launchPicker(blockId: Int) {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "font/ttf", "font/otf", "application/x-font-ttf", "application/x-font-opentype",
                "application/zip", "application/x-zip-compressed", "application/octet-stream"
            ))
        }
        pendingBlockId = blockId
        startActivityForResult(intent, pickerRequest)
    }

    private var pendingBlockId: Int = -1

    @Deprecated("Kept for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == saveRequest) {
            if (resultCode != RESULT_OK) return
            val uri = data?.data ?: return
            val source = pendingSaveFile ?: return
            try {
                contentResolver.openOutputStream(uri, "w").use { output ->
                    if (output == null) throw Exception("تعذر فتح مكان الحفظ")
                    source.inputStream().use { input -> input.copyTo(output) }
                }
                Toast.makeText(this, "تم حفظ ملف الخط فقط", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(this, "تعذر حفظ الخط: ${e.message ?: "خطأ غير معروف"}", Toast.LENGTH_LONG).show()
            } finally {
                pendingSaveFile = null
            }
            return
        }
        if (requestCode != pickerRequest || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        val block = blocks.firstOrNull { it.id == pendingBlockId } ?: return
        val name = queryName(uri) ?: "font-file"
        try {
            val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
            if (ext == "zip") {
                val choices = extractFontsFromZip(uri)
                if (choices.isEmpty()) {
                    Toast.makeText(this, "لم أجد ملفات TTF أو OTF أو TTC صالحة داخل ZIP", Toast.LENGTH_LONG).show()
                } else {
                    showZipFontChooser(choices)
                }
            } else {
                val temp = File(cacheDir, "font_${System.currentTimeMillis()}_${safeName(name)}")
                contentResolver.openInputStream(uri).use { input ->
                    if (input == null) throw Exception("تعذرت قراءة الملف")
                    FileOutputStream(temp).use { output -> input.copyTo(output) }
                }
                if (ext in listOf("ttf", "otf", "ttc")) {
                    val metadata = readFontNames(temp)
                    applyFont(block, FontChoice(name, temp,
                        metadata.first ?: name.substringBeforeLast('.', name),
                        metadata.second ?: inferStyleFromFilename(name), ext))
                } else {
                    block.fileLabel.text = "$name\nالصيغة محفوظة، لكن المعاينة المباشرة لهذه الصيغة غير مضمونة على Android."
                    Toast.makeText(this, "الصيغة غير مدعومة للمعاينة المباشرة حاليًا", Toast.LENGTH_LONG).show()
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "تعذر فتح الملف: ${e.message ?: "خطأ غير معروف"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun extractFontsFromZip(uri: Uri): List<FontChoice> {
        val extracted = mutableListOf<FontChoice>()
        contentResolver.openInputStream(uri).use { raw ->
            if (raw == null) throw Exception("تعذر فتح ZIP")
            ZipInputStream(raw).use { zip ->
                var entry = zip.nextEntry
                var examined = 0
                while (entry != null && examined < 250) {
                    examined++
                    val ext = entry.name.substringAfterLast('.', "").lowercase(Locale.ROOT)
                    if (!entry.isDirectory && ext in listOf("ttf", "otf", "ttc")) {
                        val baseName = entry.name.substringAfterLast('/')
                        val file = File(cacheDir, "zipfont_${System.currentTimeMillis()}_${extracted.size}_${safeName(baseName)}")
                        FileOutputStream(file).use { out ->
                            val buffer = ByteArray(8192)
                            var total = 0L
                            while (true) {
                                val count = zip.read(buffer)
                                if (count < 0) break
                                if (count == 0) continue
                                total += count
                                if (total > 25L * 1024 * 1024) throw Exception("أحد الخطوط داخل ZIP أكبر من 25MB")
                                out.write(buffer, 0, count)
                            }
                        }
                        val metadata = readFontNames(file)
                        val family = metadata.first?.takeIf { it.isNotBlank() }
                            ?: baseName.substringBeforeLast('.', baseName).replace(Regex("[-_]+"), " ")
                        val style = metadata.second?.takeIf { it.isNotBlank() }
                            ?: inferStyleFromFilename(baseName)
                        try {
                            // Reject corrupt or unsupported font files before showing them in the chooser.
                            Typeface.createFromFile(file)
                            extracted.add(FontChoice(baseName, file, family, style, ext))
                        } catch (_: Exception) {
                            file.delete()
                        }
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
        }

        // Collapse copies of the same family/style. Prefer TTF, then OTF, then TTC as a practical default.
        val priority = mapOf("ttf" to 0, "otf" to 1, "ttc" to 2)
        return extracted.groupBy { it.identity }.values.map { sameFont ->
            sameFont.minWithOrNull(compareBy<FontChoice> { priority[it.extension] ?: 9 }.thenBy { it.file.length() })!!
        }.sortedBy { it.displayName.lowercase(Locale.ROOT) }
    }

    private fun showZipFontChooser(choices: List<FontChoice>) {
        val labels = choices.map { choice ->
            "${choice.displayName}  ·  ${choice.extension.uppercase(Locale.ROOT)}  ·  ${choice.file.length() / 1024} KB"
        }.toTypedArray()
        val checked = BooleanArray(choices.size) { true }
        AlertDialog.Builder(this)
            .setTitle("اختار الخطوط اللي عايز تعرضها")
            .setMultiChoiceItems(labels, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton("إنشاء البلوكات المحددة") { _, _ ->
                val selected = choices.filterIndexed { index, _ -> checked[index] }
                if (selected.isEmpty()) {
                    Toast.makeText(this, "اختار خطًا واحدًا على الأقل", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                // A ZIP selection is a new comparison set, so create exactly one block per selected font.
                blocksHost.removeAllViews()
                blocks.clear()
                selected.forEach { choice ->
                    addPreviewBlock()
                    applyFont(blocks.last(), choice)
                }
                Toast.makeText(this, "تم إنشاء ${selected.size} بلوك للمعاينة", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun saveBlockFont(blockId: Int) {
        val block = blocks.firstOrNull { it.id == blockId } ?: return
        val file = block.fontFile
        if (file == null || !file.exists()) {
            Toast.makeText(this, "اختار خطًا لهذا البلوك أولًا", Toast.LENGTH_SHORT).show()
            return
        }
        val ext = file.extension.takeIf { it.isNotBlank() } ?: "ttf"
        val original = block.sourceName.ifBlank { "font.$ext" }
        val suggested = if (original.substringAfterLast('.', "").equals(ext, true)) original else "${block.fontName.ifBlank { "font" }}.$ext"
        pendingSaveFile = file
        pendingSaveName = safeName(suggested).ifBlank { "font.$ext" }
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = when (ext.lowercase(Locale.ROOT)) {
                "otf" -> "application/x-font-opentype"
                "ttc" -> "application/octet-stream"
                else -> "application/x-font-ttf"
            }
            putExtra(Intent.EXTRA_TITLE, pendingSaveName)
        }
        startActivityForResult(intent, saveRequest)
    }

    private fun showColorPalette(block: PreviewBlock?, isTextColor: Boolean) {
        if (block == null) return
        val colors = intArrayOf(
            Color.WHITE, Color.BLACK, Color.RED, Color.rgb(255, 152, 0), Color.YELLOW,
            Color.GREEN, Color.rgb(0, 188, 212), Color.BLUE, Color.rgb(156, 39, 176), Color.rgb(255, 64, 129)
        )
        val names = arrayOf("أبيض", "أسود", "أحمر", "برتقالي", "أصفر", "أخضر", "سماوي", "أزرق", "بنفسجي", "وردي", "مخصص — دائرة ألوان وكود")
        val rows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), dp(8)) }
        val grid = android.widget.GridLayout(this).apply { columnCount = 5; rowCount = 2 }
        colors.forEachIndexed { index, color ->
            val chip = TextView(this).apply {
                text = "●"
                textSize = 28f
                gravity = Gravity.CENTER
                setTextColor(color)
                contentDescription = names[index]
                setPadding(dp(4), dp(4), dp(4), dp(4))
            }
            grid.addView(chip, android.widget.GridLayout.LayoutParams().apply {
                width = 0; height = dp(50); columnSpec = android.widget.GridLayout.spec(index % 5, 1f)
            })
        }
        rows.addView(grid)
        val custom = button("＋  لون مخصص · دائرة ألوان / HEX") { }
        rows.addView(custom, marginParams(top = 8))
        val colorDialog = AlertDialog.Builder(this).setTitle(if (isTextColor) "اختيار لون النص" else "اختيار لون الخلفية")
            .setView(rows).setNegativeButton("إغلاق", null).create()
        // Rebind chips after dialog creation so the click handlers can close it safely.
        for (i in 0 until grid.childCount) {
            val chip = grid.getChildAt(i) as TextView
            chip.setOnClickListener { applyPreviewColor(block, isTextColor, colors[i]); colorDialog.dismiss() }
        }
        custom.setOnClickListener { colorDialog.dismiss(); showCustomColorDialog(block, isTextColor) }
        colorDialog.show()
    }

    private fun applyPreviewColor(block: PreviewBlock, isTextColor: Boolean, color: Int) {
        if (isTextColor) {
            block.textColor = color
            block.preview.setTextColor(color)
            block.textColorButton?.setTextColor(color)
        } else {
            block.previewBackground = color
            block.preview.background = solidPreviewBackground(color, if (isLight(color)) violet else cyan)
            block.backgroundColorButton?.setBackground(GradientDrawable().apply {
                cornerRadius = dp(15).toFloat()
                setColor(color)
                setStroke(dp(1), Color.argb(180, 255, 255, 255))
            })
            block.backgroundColorButton?.setTextColor(if (isLight(color)) Color.BLACK else Color.WHITE)
        }
    }

    private fun showCustomColorDialog(block: PreviewBlock, isTextColor: Boolean) {
        val current = if (isTextColor) block.textColor else block.previewBackground
        val hsv = FloatArray(3)
        Color.colorToHSV(current, hsv)
        var chosenColor = current
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(12), dp(18), dp(4)) }
        val code = EditText(this).apply {
            setSingleLine(true)
            hint = "#RRGGBB أو #AARRGGBB"
            setText(String.format(Locale.US, "#%06X", 0xFFFFFF and current))
            setTextColor(primaryText)
            setHintTextColor(muted)
            background = glass(0x20FFFFFF, cyan)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        val wheel = ColorWheelView(hsv[0], hsv[1]) { color ->
            chosenColor = color
            code.setText(String.format(Locale.US, "#%06X", 0xFFFFFF and chosenColor))
        }
        layout.addView(wheel, LinearLayout.LayoutParams(-1, dp(230)))
        layout.addView(TextView(this).apply { text = "كود اللون HEX"; setTextColor(primaryText); textSize = 13f; setPadding(0, dp(8), 0, dp(4)) })
        layout.addView(code)
        val swatch = TextView(this).apply { text = "معاينة اللون"; gravity = Gravity.CENTER; setTextColor(Color.WHITE); background = solidPreviewBackground(current, violet); setPadding(0, dp(10), 0, dp(10)) }
        layout.addView(swatch, marginParams(top = 8))
        wheel.onColorChanged = { color ->
            chosenColor = color
            if (!code.hasFocus()) code.setText(String.format(Locale.US, "#%06X", 0xFFFFFF and color))
            swatch.background = solidPreviewBackground(color, violet)
            swatch.setTextColor(if (isLight(color)) Color.BLACK else Color.WHITE)
        }
        code.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val parsed = parseHexColor(s?.toString().orEmpty()) ?: return
                chosenColor = parsed
                swatch.background = solidPreviewBackground(parsed, violet)
                swatch.setTextColor(if (isLight(parsed)) Color.BLACK else Color.WHITE)
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        AlertDialog.Builder(this)
            .setTitle(if (isTextColor) "لون نص مخصص" else "لون خلفية مخصص")
            .setView(layout)
            .setPositiveButton("تطبيق") { _, _ ->
                val parsed = parseHexColor(code.text.toString())
                applyPreviewColor(block, isTextColor, parsed ?: chosenColor)
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun parseHexColor(value: String): Int? = try {
        val clean = value.trim().removePrefix("#")
        when (clean.length) {
            6 -> Color.parseColor("#$clean")
            8 -> Color.parseColor("#$clean")
            else -> null
        }
    } catch (_: Exception) { null }

    private fun isLight(color: Int): Boolean {
        val luminance = (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color)) / 255
        return luminance > 0.62
    }

    private fun solidPreviewBackground(color: Int, edge: Int) = GradientDrawable().apply {
        cornerRadius = dp(18).toFloat()
        setColor(color)
        setStroke(dp(1), Color.argb(180, Color.red(edge), Color.green(edge), Color.blue(edge)))
    }

    private inner class ColorWheelView(
        initialHue: Float,
        initialSaturation: Float,
        var onColorChanged: ((Int) -> Unit)? = null
    ) : View(this@MainActivity) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var hue = initialHue
        private var saturation = initialSaturation
        private var cx = 0f
        private var cy = 0f
        private var radius = 0f
        init { setLayerType(View.LAYER_TYPE_SOFTWARE, null) }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            cx = width / 2f; cy = height / 2f
            radius = (minOf(width, height) / 2f) - dp(12)
            if (radius <= 0f) return
            paint.shader = SweepGradient(cx, cy, intArrayOf(Color.RED, Color.YELLOW, Color.GREEN, Color.CYAN, Color.BLUE, Color.MAGENTA, Color.RED), null)
            canvas.drawCircle(cx, cy, radius, paint)
            paint.shader = RadialGradient(cx, cy, radius, intArrayOf(Color.WHITE, Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
            canvas.drawCircle(cx, cy, radius, paint)
            paint.shader = null
            paint.style = Paint.Style.STROKE; paint.strokeWidth = dp(2).toFloat(); paint.color = Color.WHITE
            val angle = Math.toRadians(hue.toDouble())
            val markerR = radius * saturation
            canvas.drawCircle(cx + kotlin.math.cos(angle).toFloat() * markerR, cy + kotlin.math.sin(angle).toFloat() * markerR, dp(7).toFloat(), paint)
            paint.style = Paint.Style.FILL
        }
        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (event.action != MotionEvent.ACTION_DOWN && event.action != MotionEvent.ACTION_MOVE && event.action != MotionEvent.ACTION_UP) return true
            val dx = event.x - cx; val dy = event.y - cy
            hue = ((Math.toDegrees(kotlin.math.atan2(dy.toDouble(), dx.toDouble())) + 360.0) % 360.0).toFloat()
            saturation = (kotlin.math.sqrt(dx * dx + dy * dy) / radius).coerceIn(0f, 1f)
            invalidate()
            val color = Color.HSVToColor(floatArrayOf(hue, saturation, 1f))
            onColorChanged?.invoke(color)
            return true
        }
    }

    private fun inferStyleFromFilename(filename: String): String {
        val lower = filename.lowercase(Locale.ROOT)
        return when {
            "thin" in lower -> "Thin"
            "extralight" in lower || "extra-light" in lower -> "ExtraLight"
            "light" in lower -> "Light"
            "medium" in lower -> "Medium"
            "semibold" in lower || "semi-bold" in lower -> "SemiBold"
            "extrabold" in lower || "extra-bold" in lower -> "ExtraBold"
            "black" in lower || "heavy" in lower -> "Black"
            "bold" in lower -> "Bold"
            "italic" in lower || "oblique" in lower -> "Italic"
            else -> "Regular"
        }
    }

    /** Reads family and subfamily names from the OpenType/SFNT name table. TTC uses its first face. */
    private fun readFontNames(file: File): Pair<String?, String?> {
        return try {
            val bytes = file.readBytes()
            val b = ByteBuffer.wrap(bytes).order(ByteOrder.BIG_ENDIAN)
            if (bytes.size < 12) return Pair(null, null)
            val signature = String(bytes, 0, 4, Charsets.ISO_8859_1)
            val sfntOffset = if (signature == "ttcf" && bytes.size >= 16) b.getInt(12).toLong() else 0L
            if (sfntOffset < 0 || sfntOffset + 12 > bytes.size) return Pair(null, null)
            val numTables = b.getShort((sfntOffset + 4).toInt()).toInt() and 0xffff
            var nameOffset = -1L
            var nameLength = 0L
            for (i in 0 until numTables) {
                val record = sfntOffset + 12 + i * 16L
                if (record + 16 > bytes.size) break
                val tag = String(bytes, record.toInt(), 4, Charsets.ISO_8859_1)
                if (tag == "name") {
                    nameOffset = b.getInt((record + 8).toInt()).toLong() and 0xffffffffL
                    nameLength = b.getInt((record + 12).toInt()).toLong() and 0xffffffffL
                    break
                }
            }
            if (nameOffset < 0 || nameLength < 6 || nameOffset + nameLength > bytes.size) return Pair(null, null)
            val table = nameOffset.toInt()
            val count = b.getShort(table + 2).toInt() and 0xffff
            val stringStorage = table + (b.getShort(table + 4).toInt() and 0xffff)
            var family: String? = null
            var subfamily: String? = null
            var fullName: String? = null
            for (i in 0 until count) {
                val rec = table + 6 + i * 12
                if (rec + 12 > bytes.size || rec + 12 > nameOffset + nameLength) break
                val platform = b.getShort(rec).toInt() and 0xffff
                val nameId = b.getShort(rec + 6).toInt() and 0xffff
                val length = b.getShort(rec + 8).toInt() and 0xffff
                val offset = b.getShort(rec + 10).toInt() and 0xffff
                if (nameId !in listOf(1, 2, 4, 16, 17)) continue
                val pos = stringStorage + offset
                if (pos < 0 || pos + length > bytes.size) continue
                val charset = if (platform == 0 || platform == 3) Charsets.UTF_16BE else Charsets.ISO_8859_1
                val value = String(bytes, pos, length, charset).replace("\u0000", "").trim()
                if (value.isBlank()) continue
                when (nameId) {
                    16 -> if (family == null || platform == 3) family = value
                    1 -> if (family == null) family = value
                    17 -> if (subfamily == null || platform == 3) subfamily = value
                    2 -> if (subfamily == null) subfamily = value
                    4 -> if (fullName == null) fullName = value
                }
            }
            Pair(family ?: fullName, subfamily)
        } catch (_: Exception) {
            Pair(null, null)
        }
    }

    private fun applyFont(block: PreviewBlock, choice: FontChoice) {
        try {
            val face = Typeface.createFromFile(choice.file)
            block.fontFile = choice.file
            block.fontName = choice.displayName
            block.sourceName = choice.name
            block.preview.typeface = face
            block.fileLabel.text = "✓ ${choice.displayName}  •  ${choice.extension.uppercase(Locale.ROOT)}  •  جاهز للمعاينة"
            Toast.makeText(this, "تم تحميل الخط لهذا البلوك", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            block.fileLabel.text = "تعذر تحميل ${choice.name} للمعاينة. جرّب ملف TTF أو OTF صالحًا."
            Toast.makeText(this, "تعذر قراءة ملف الخط", Toast.LENGTH_LONG).show()
        }
    }

    private fun queryName(uri: Uri): String? {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0)
        }
        return uri.lastPathSegment?.substringAfterLast('/')
    }

    private fun safeName(name: String) = name.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._-]"), "_").take(90)

    private fun glass(fill: Int, edge: Int): GradientDrawable = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(fill, Color.argb(25, 255, 255, 255), fill)
    ).apply {
        cornerRadius = dp(20).toFloat()
        setStroke(dp(1), Color.argb(125, Color.red(edge), Color.green(edge), Color.blue(edge)))
    }

    private fun button(caption: String, action: () -> Unit) = Button(this).apply {
        text = caption
        textSize = 13f
        isAllCaps = false
        setTextColor(primaryText)
        background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(Color.rgb(89, 64, 174), Color.rgb(29, 133, 168))).apply { cornerRadius = dp(15).toFloat() }
        setPadding(dp(8), dp(5), dp(8), dp(5))
        stateListAnimator = null
        setOnClickListener { action() }
    }

    private fun marginParams(bottom: Int = 0, top: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply {
        if (bottom > 0) bottomMargin = dp(bottom)
        if (top > 0) topMargin = dp(top)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
