package com.local.fontanalyzer

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

class MainActivity : Activity() {
    private val pickFontRequest = 101
    private var selectedUri: Uri? = null
    private var selectedName: String = ""
    private lateinit var info: TextView
    private lateinit var preview: TextView
    private lateinit var sampleInput: EditText
    private lateinit var sizeInput: EditText
    private lateinit var saveButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(14, 20, 38)
        window.navigationBarColor = android.graphics.Color.rgb(14, 20, 38)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
            setBackgroundColor(android.graphics.Color.rgb(14, 20, 38))
        }

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(content)

        val title = TextView(this).apply {
            text = "FONT ANALYZER"
            textSize = 27f
            setTextColor(android.graphics.Color.rgb(112, 225, 255))
            typeface = Typeface.DEFAULT_BOLD
        }
        content.addView(title)
        content.addView(label("استورد الخط، افحص بياناته، وعاينه واحفظه محليًا."))

        val pickButton = button("＋  اختيار ملف الخط")
        pickButton.setOnClickListener { openPicker() }
        content.addView(pickButton)

        info = label("لم يتم اختيار ملف بعد.")
        info.setPadding(dp(12), dp(12), dp(12), dp(12))
        info.setBackgroundColor(android.graphics.Color.rgb(26, 36, 59))
        content.addView(info)

        content.addView(label("نص المعاينة"))
        sampleInput = EditText(this).apply {
            setText("Qworld — Hello World — مرحباً بك — 0123456789")
            setTextColor(android.graphics.Color.WHITE)
            setHintTextColor(android.graphics.Color.LTGRAY)
            setHint("اكتب النص الذي تريد معاينته")
            setBackgroundColor(android.graphics.Color.rgb(26, 36, 59))
        }
        content.addView(sampleInput)

        content.addView(label("حجم الخط (من 12 إلى 72)"))
        sizeInput = EditText(this).apply {
            setText("30")
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setTextColor(android.graphics.Color.WHITE)
            setBackgroundColor(android.graphics.Color.rgb(26, 36, 59))
        }
        content.addView(sizeInput)

        val previewButton = button("معاينة النص")
        previewButton.setOnClickListener { updatePreview() }
        content.addView(previewButton)

        preview = TextView(this).apply {
            text = "تظهر المعاينة هنا"
            textSize = 30f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.WHITE)
            setPadding(dp(12), dp(24), dp(12), dp(24))
            setBackgroundColor(android.graphics.Color.rgb(26, 36, 59))
        }
        content.addView(preview)

        saveButton = button("حفظ نسخة من الخط في Documents/FontAnalyzer")
        saveButton.isEnabled = false
        saveButton.setOnClickListener { saveFont() }
        content.addView(saveButton)

        content.addView(label("ملاحظة: المعاينة المباشرة تعتمد على صيغة الخط. ملفات TTF وOTF هي الأفضل دعمًا؛ باقي الصيغ قد تحتاج تحويلًا."))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun openPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(intent, pickFontRequest)
    }

    @Deprecated("Deprecated by Android, retained for compatibility with broad device support")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickFontRequest || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        selectedUri = uri
        selectedName = queryName(uri) ?: "font_file"
        val size = querySize(uri)
        val ext = selectedName.substringAfterLast('.', "").lowercase(Locale.ROOT)
        val supported = ext in listOf("ttf", "otf", "ttc")
        val details = buildString {
            append("الملف: $selectedName\n")
            append("الامتداد: ${if (ext.isBlank()) "غير معروف" else ext.uppercase(Locale.ROOT)}\n")
            append("الحجم: ${if (size >= 0) formatBytes(size) else "غير متاح"}\n")
            append("المعاينة: ")
            append(if (supported) "يمكن محاولة عرض الخط مباشرة." else "قد لا تدعم Android هذه الصيغة مباشرة؛ يمكن حفظ الملف الأصلي.")
        }
        info.text = details
        saveButton.isEnabled = true
        if (supported) {
            try {
                contentResolver.openInputStream(uri)?.use { input ->
                    val temp = File(cacheDir, "preview_font_${System.currentTimeMillis()}.$ext")
                    temp.outputStream().use { output -> input.copyTo(output) }
                    preview.typeface = Typeface.createFromFile(temp)
                    temp.deleteOnExit()
                    Toast.makeText(this, "تم تحميل الخط للمعاينة", Toast.LENGTH_SHORT).show()
                }
            } catch (_: Exception) {
                preview.typeface = Typeface.DEFAULT
                Toast.makeText(this, "تعذر عرض الخط مباشرة، لكن يمكنك حفظ الملف", Toast.LENGTH_LONG).show()
            }
        } else {
            preview.typeface = Typeface.DEFAULT
        }
        updatePreview()
    }

    private fun updatePreview() {
        preview.text = sampleInput.text?.toString().orEmpty().ifBlank { "اكتب نصًا للمعاينة" }
        val size = sizeInput.text?.toString()?.toFloatOrNull()?.coerceIn(12f, 72f) ?: 30f
        preview.textSize = size
    }

    private fun saveFont() {
        val uri = selectedUri ?: return
        try {
            val dir = File(getExternalFilesDir(null), "FontAnalyzer")
            if (!dir.exists() && !dir.mkdirs()) throw Exception("تعذر إنشاء المجلد")
            val safeName = selectedName.replace(Regex("[\\\\/:*?\"<>|]"), "_")
            var target = File(dir, safeName)
            var counter = 1
            while (target.exists()) {
                val stem = safeName.substringBeforeLast('.', safeName)
                val ext = safeName.substringAfterLast('.', "")
                target = File(dir, if (ext.isBlank()) "$stem ($counter)" else "$stem ($counter).$ext")
                counter++
            }
            contentResolver.openInputStream(uri).use { input ->
                if (input == null) throw Exception("تعذر قراءة الملف")
                FileOutputStream(target).use { output -> input.copyTo(output) }
            }
            Toast.makeText(this, "تم الحفظ داخل مجلد التطبيق:\n${target.absolutePath}", Toast.LENGTH_LONG).show()
            info.append("\n\nتم حفظ نسخة: ${target.name}")
        } catch (e: Exception) {
            Toast.makeText(this, "فشل الحفظ: ${e.message ?: "خطأ غير معروف"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun queryName(uri: Uri): String? {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0)
        }
        return uri.lastPathSegment?.substringAfterLast('/')
    }

    private fun querySize(uri: Uri): Long {
        contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
            if (c.moveToFirst() && !c.isNull(0)) return c.getLong(0)
        }
        return -1
    }

    private fun formatBytes(bytes: Long): String = when {
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> String.format(Locale.US, "%.1f KB", bytes / 1024.0)
        else -> String.format(Locale.US, "%.2f MB", bytes / (1024.0 * 1024.0))
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 15f
        setTextColor(android.graphics.Color.rgb(220, 230, 245))
        setPadding(0, dp(10), 0, dp(10))
    }

    private fun button(text: String) = Button(this).apply {
        this.text = text
        textSize = 14f
        isAllCaps = false
        setTextColor(android.graphics.Color.WHITE)
        setBackgroundColor(android.graphics.Color.rgb(38, 113, 155))
        val params = LinearLayout.LayoutParams(-1, -2)
        params.setMargins(0, dp(8), 0, dp(8))
        layoutParams = params
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
